This version of html files makes all the option buttons in User Flow 1, 2 and Other Screens as the same width.
So buttons align.

The HTML pages "Tap or Insert Card" and "Insert Transit Card" is not include.
Since they don't contain any buttons, and the picture has changed.

I also add a "Complete Payment" html page for cash payment, in the OtherScreens folder.

