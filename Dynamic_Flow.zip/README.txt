Press image on the first page
https://www.google.com/url?sa=i&url=https%3A%2F%2Ficonduck.com%2Ficons%2F117087%2Fpress&psig=AOvVaw1yphez75ScgDRQZKk53umX&ust=1741810540308000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCKjLrYbsgowDFQAAAAAdAAAAABAS


Cash image in the Complete_Payment.html
https://www.flaticon.com/free-icon/cash-money_3692056


Arrow_Down in the Complete_Payment.html
https://www.iconarchive.com/show/flat-cute-arrows-icons-by-custom-icon-design/Button-Arrow-Down-1-icon.html

Tap Card image
https://www.rfidtagworld.com/news/rfid-13.56-mhz.html
